# CSamba WordPress Theme — v0.1

Tema customizado criado do zero a partir dos três layouts fornecidos:
- Home
- Arquivo de bandas (A–Z)
- Página individual de banda

## Instalação
1. Copie a pasta `csamba-theme` para `wp-content/themes/`.
2. Ative **CSamba** em Aparência > Temas.
3. Vá em Configurações > Links permanentes e clique em **Salvar alterações** uma vez.
4. Cadastre conteúdo nos tipos: Bandas, Casas, Agenda e Colunas.
5. Use Imagem destacada para as fotos de cada item.
6. Em Aparência > Menus, crie um menu e atribua a `Menu principal` se quiser substituir o menu padrão.

## Templates
- `front-page.php` — home
- `archive-banda.php` — /bandas/
- `single-banda.php` — página de uma banda

## Observação
Os JPGs enviados são referências visuais completas, não arquivos-fonte com assets separados. Por isso imagens/logos/anúncios foram recriados como estrutura/placeholder; ao receber os assets originais, basta trocá-los sem refazer o tema.
