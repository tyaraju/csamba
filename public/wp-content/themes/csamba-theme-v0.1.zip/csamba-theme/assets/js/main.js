(() => {
  const nav = document.querySelector('.main-nav');
  if (!nav) return;
  const btn = document.createElement('button');
  btn.className = 'nav-toggle';
  btn.type = 'button';
  btn.setAttribute('aria-expanded', 'false');
  btn.textContent = 'MENU';
  nav.parentNode.insertBefore(btn, nav);
  btn.addEventListener('click', () => {
    const open = document.body.classList.toggle('nav-open');
    btn.setAttribute('aria-expanded', String(open));
  });
})();
