<?php get_header(); ?>
<?php
$bands = get_posts(['post_type'=>'banda','posts_per_page'=>4]);
$houses = get_posts(['post_type'=>'casa','posts_per_page'=>1]);
$news = get_posts(['post_type'=>'post','posts_per_page'=>5]);
$events = get_posts(['post_type'=>'agenda','posts_per_page'=>6]);
$columns = get_posts(['post_type'=>'coluna','posts_per_page'=>3]);
$hero = $bands[0] ?? null;
?>
<div class="container home-grid">
  <section class="hero-card">
    <div class="hero-media"><img src="<?php echo esc_url($hero ? csamba_image_url($hero->ID,'large','Banda em destaque') : csamba_placeholder('Banda em destaque')); ?>" alt=""></div>
    <div class="hero-copy">
      <div class="hero-arrow">→</div>
      <h1><?php echo $hero ? esc_html(get_the_title($hero)) : 'EXALTASAMBA'; ?></h1>
      <h2><?php echo $hero ? 'EM DESTAQUE' : 'LANÇA CD EM PORTO ALEGRE'; ?></h2>
      <p><?php echo $hero ? esc_html(wp_trim_words(wp_strip_all_tags($hero->post_content),28)) : 'Conteúdo de destaque do CSamba. Cadastre bandas e matérias no WordPress para substituir os textos demonstrativos.'; ?></p>
      <a class="btn btn-light" href="<?php echo $hero ? esc_url(get_permalink($hero)) : '#'; ?>">VEJA MAIS →</a>
    </div>
    <aside class="other-highlights">
      <h3>OUTROS<br>DESTAQUES</h3><small>clique abaixo para ver<br>os outros destaques</small>
      <?php foreach(['EXALTA EM POA','SORRISO NOVO CD','REGIÃO DE JAC','COLINHO VERMELHO','JEITO MOLEQUE TEM SHOW','FUNDO DE QUINTAL','ORDEM DA SEGUNDA'] as $idx=>$t): ?>
        <a href="#" class="stripe s<?php echo $idx+1; ?>"><?php echo esc_html($t); ?></a>
      <?php endforeach; ?>
    </aside>
  </section>

  <section class="split-row">
    <div class="home-section houses">
      <h2><span>CASAS</span><strong>DE SAMBA E PAGODE</strong></h2>
      <?php $house=$houses[0]??null; ?>
      <article class="house-card">
        <img src="<?php echo esc_url($house ? csamba_image_url($house->ID,'medium','Casa de samba') : csamba_placeholder('Casa de samba')); ?>" alt="">
        <div><h3><?php echo $house ? esc_html(get_the_title($house)) : 'Chalaca'; ?></h3><p><?php echo $house ? esc_html(wp_trim_words(wp_strip_all_tags($house->post_content),24)) : 'Cadastre casas de samba no painel para preencher esta seção.'; ?></p></div>
      </article>
      <div class="select-line"><span>Veja outras casas</span><select><option>Selecione</option></select><button>BUSCAR →</button></div>
    </div>
    <div class="home-section featured-bands">
      <div class="section-title-row"><h2><span>BANDAS</span><strong>EM DESTAQUE</strong></h2><a class="mini-btn" href="<?php echo esc_url(get_post_type_archive_link('banda')); ?>">VEJA TODAS AS BANDAS</a></div>
      <div class="band-cards">
        <?php foreach(array_slice($bands,0,3) as $b): ?><article><img src="<?php echo esc_url(csamba_image_url($b->ID,'medium',get_the_title($b))); ?>" alt=""><h3><?php echo esc_html(get_the_title($b)); ?></h3><p><?php echo esc_html(wp_trim_words(wp_strip_all_tags($b->post_content),12)); ?></p><a href="<?php echo esc_url(get_permalink($b)); ?>">clique aqui</a></article><?php endforeach; ?>
        <?php if(!$bands): foreach(['Pixote','Fundo de Quintal','Zueira'] as $name): ?><article><img src="<?php echo esc_url(csamba_placeholder($name)); ?>" alt=""><h3><?php echo esc_html($name); ?></h3><p>Conteúdo demonstrativo da banda.</p><a href="#">clique aqui</a></article><?php endforeach; endif; ?>
      </div>
    </div>
  </section>

  <section class="content-columns">
    <div class="news-col">
      <div class="headline"><h2>NOVIDADES <strong>CSAMBA</strong></h2><span>PATROCINADO POR <b>ITAÚ 10:46</b></span></div>
      <?php if($news): foreach($news as $n): setup_postdata($n); ?>
        <div class="date-line"><?php echo esc_html(csamba_date_label($n->ID)); ?></div>
        <article class="news-card">
          <?php if(has_post_thumbnail($n->ID)): ?><img src="<?php echo esc_url(csamba_image_url($n->ID,'medium',get_the_title($n))); ?>" alt=""><?php endif; ?>
          <div class="news-copy"><h3><?php echo esc_html(get_the_title($n)); ?></h3><p><?php echo esc_html(wp_trim_words(wp_strip_all_tags($n->post_content),34)); ?></p></div>
          <div class="news-actions"><a href="<?php echo esc_url(get_permalink($n)); ?>">VEJA TODA A NOTÍCIA →</a><span>☆ GOSTEI</span><span>ENVIE ESSA NOTÍCIA ✉</span></div>
        </article>
      <?php endforeach; wp_reset_postdata(); else: foreach(['Pixote','Jeito Moleque invade Viamão','Zueira no Opinião','Zueira no Opinião','Zueira no Opinião'] as $i=>$name): ?>
        <div class="date-line">23 de abril de 2009</div><article class="news-card"><?php if($i===1): ?><img src="<?php echo esc_url(csamba_placeholder('Jeito Moleque')); ?>" alt=""><?php endif; ?><div class="news-copy"><h3><?php echo esc_html($name); ?></h3><p>Conteúdo de demonstração. Publique notícias no WordPress para substituir este bloco.</p></div><div class="news-actions"><a href="#">VEJA TODA A NOTÍCIA →</a><span>☆ GOSTEI</span><span>ENVIE ESSA NOTÍCIA ✉</span></div></article>
      <?php endforeach; endif; ?>
      <div class="pager"><a href="#">← anterior</a><a href="#">próximo →</a></div>
    </div>

    <aside class="sidebar-home">
      <div class="headline"><h2>AGENDA <strong>CSAMBA</strong></h2><span>PATROCINADO POR <b>Bradesco</b></span></div>
      <div class="agenda-list">
        <?php $days=['SEG','TER','QUA']; $items=$events ?: array_fill(0,6,null); foreach($items as $i=>$event): if($i%2===0): ?><div class="agenda-day"><?php echo $days[min(2,intdiv($i,2))]; ?></div><?php endif; ?><div class="agenda-row"><b>CHILECO</b><span><?php echo $event ? esc_html(get_the_title($event)) : 'Lorem ipsum is simply dummy'; ?></span></div><?php endforeach; ?>
      </div>
      <a class="btn" href="<?php echo esc_url(home_url('/agenda/')); ?>">VEJA TODA A AGENDA →</a>
      <div class="promo-grid">
        <div><div class="promo-icon">♥</div><h3>CADASTRE-SE</h3><p>saiba como aproveitar ao máximo o CSamba</p><a href="#">clique aqui</a></div>
        <div><div class="promo-icon">▶</div><h3>RÁDIO WEB</h3><p>Ouça já a rádio CSamba</p><strong>NO AR</strong></div>
        <div><div class="promo-icon">◉</div><h3>PODCAST</h3><p>Baixe o iTunes e ouça o podcast</p><a href="#">baixar</a></div>
      </div>
      <div class="columns-block">
        <div class="headline simple"><h2>COLUNAS <strong>CSAMBA</strong></h2></div>
        <div class="column-cards">
          <?php if($columns): foreach($columns as $c): ?><article><small>COLUNA</small><h3><?php echo esc_html(get_the_title($c)); ?></h3><img src="<?php echo esc_url(csamba_image_url($c->ID,'medium',get_the_title($c))); ?>" alt=""><p><?php echo esc_html(wp_trim_words(wp_strip_all_tags($c->post_content),18)); ?></p><a href="<?php echo esc_url(get_permalink($c)); ?>">clique aqui</a></article><?php endforeach; else: foreach(['Divã chega a cartaz','MNG lança coleção','Exaltasamba lança CD'] as $name): ?><article><small>CINEMA</small><h3><?php echo esc_html($name); ?></h3><img src="<?php echo esc_url(csamba_placeholder($name)); ?>" alt=""><p>Foi nessa loja que apresentamos o conteúdo.</p><a href="#">clique aqui</a></article><?php endforeach; endif; ?>
        </div>
      </div>
    </aside>
  </section>
</div>
<?php get_footer(); ?>
