<?php
if (!defined('ABSPATH')) exit;

define('CSAMBA_VERSION', '0.1.0');

function csamba_setup(): void {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','gallery','caption','style','script']);
    register_nav_menus([
        'primary' => 'Menu principal',
        'band'    => 'Menu da banda',
    ]);
}
add_action('after_setup_theme', 'csamba_setup');

function csamba_assets(): void {
    wp_enqueue_style('csamba-main', get_template_directory_uri() . '/assets/css/main.css', [], CSAMBA_VERSION);
    wp_enqueue_script('csamba-main', get_template_directory_uri() . '/assets/js/main.js', [], CSAMBA_VERSION, true);
}
add_action('wp_enqueue_scripts', 'csamba_assets');

function csamba_register_content_types(): void {
    $types = [
        'banda' => ['Bandas','Banda','dashicons-groups'],
        'casa' => ['Casas','Casa','dashicons-admin-home'],
        'agenda' => ['Agenda','Evento','dashicons-calendar-alt'],
        'coluna' => ['Colunas','Coluna','dashicons-welcome-write-blog'],
    ];
    foreach ($types as $slug => [$plural,$singular,$icon]) {
        register_post_type($slug, [
            'labels' => ['name'=>$plural,'singular_name'=>$singular,'add_new_item'=>"Adicionar $singular",'edit_item'=>"Editar $singular"],
            'public' => true,
            'has_archive' => $slug === 'banda',
            'rewrite' => ['slug' => $slug === 'banda' ? 'bandas' : $slug],
            'menu_icon' => $icon,
            'supports' => ['title','editor','excerpt','thumbnail'],
            'show_in_rest' => true,
        ]);
    }
}
add_action('init', 'csamba_register_content_types');

function csamba_excerpt(int $words = 24): string {
    return wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), $words);
}

function csamba_placeholder(string $label='CSamba'): string {
    return 'https://placehold.co/900x560/e8e8e8/222?text=' . rawurlencode($label);
}

function csamba_image_url($post_id = null, string $size='large', string $fallback='CSamba'): string {
    $post_id = $post_id ?: get_the_ID();
    $url = get_the_post_thumbnail_url($post_id, $size);
    return $url ?: csamba_placeholder($fallback);
}

function csamba_date_label($post_id = null): string {
    $post_id = $post_id ?: get_the_ID();
    return get_the_date('j \d\e F \d\e Y', $post_id);
}
