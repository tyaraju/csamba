<?php if (!defined('ABSPATH')) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
  <div class="topbar">
    <div class="container topbar-inner">
      <form role="search" method="get" class="top-search" action="<?php echo esc_url(home_url('/')); ?>">
        <span class="search-icon">⌕</span><span class="search-label">busca</span>
        <input type="search" name="s" value="<?php echo esc_attr(get_search_query()); ?>">
        <button>BUSCAR</button>
      </form>
      <div class="member-links">♟♟♟ <a href="#">cadastre sua banda</a> | <a href="<?php echo esc_url(wp_login_url()); ?>">logar</a></div>
    </div>
  </div>
  <div class="container brand-row">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
      <span class="brand-mark">S4MBA</span>
      <span class="brand-copy">A SUA CASA<br>DO SAMBA</span>
    </a>
    <div class="ad-banner"><span>Fale de graça com todo o Brasil<br>em ligações locais e DDD.</span><strong>TIM</strong></div>
  </div>
  <div class="container nav-wrap">
    <nav class="main-nav" aria-label="Menu principal">
      <?php
      if (has_nav_menu('primary')) {
        wp_nav_menu(['theme_location'=>'primary','container'=>false,'fallback_cb'=>false,'items_wrap'=>'<ul>%3$s</ul>']);
      } else {
        echo '<ul>';
        $items = [
          ['BANDAS', get_post_type_archive_link('banda') ?: home_url('/bandas/')],
          ['COLUNAS', home_url('/coluna/')],
          ['AGENDA', home_url('/agenda/')],
          ['CASAS', home_url('/casa/')],
          ['MÚSICAS', '#'],
          ['CADASTRAR BANDA', '#'],
        ];
        foreach ($items as $i => [$name,$url]) echo '<li><a href="'.esc_url($url).'">'.esc_html($name).'</a></li>';
        echo '</ul>';
      }
      ?>
    </nav>
  </div>
</header>
<main id="main" class="site-main">
