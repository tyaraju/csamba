# CSamba Theme v0.2

Tema WordPress clássico, sem Bedrock, reconstruído a partir dos layouts históricos do CSamba e ampliado para uma largura contemporânea.

## O que mudou

- Container moderno de até 1280px, layout principal em Flexbox e gaps de 24/32px.
- Swiper no destaque principal; a coluna “Outros destaques” é a paginação clicável do slider.
- ACF local fields versionados no tema:
  - cor por item do menu principal;
  - banda em destaque;
  - subtítulo do destaque;
  - cor de fundo do botão de cada slide;
  - campos estruturados da agenda.
- Agenda agora é o CPT `evento`, com data, horário, banda, casa/local, cidade e link de ingresso.
- Consultas da agenda mostram somente eventos futuros, ordenados pela data.
- Tamanhos de imagem próprios (`csamba-card`, `csamba-hero`, `csamba-thumb`) para o WordPress gerar `srcset` adequado.
- Vite + Tailwind configurados para a próxima etapa de build.
- JavaScript vanilla para o tema; Swiper somente para o componente de destaque.

## ACF

Instale e ative o Advanced Custom Fields. Os grupos são registrados pelo próprio tema, então não é necessário importar JSON. Os campos usados nesta versão funcionam sem Repeater.

No menu do WordPress, cada item passa a ter o campo **Cor do item**.

Em Bandas, use **Exibir nos destaques**, **Subtítulo do destaque** e **Cor do botão do destaque**.

## Fonte ITC Avant Garde

O tema já possui o `@font-face`, mas o arquivo da fonte não é distribuído. Coloque sua cópia licenciada aqui:

`assets/fonts/itcavantgardegothicltbold.ttf`

## Vite + Tailwind

A versão entregue já funciona com `assets/css/main.css` e `assets/js/main.js`.

Para iniciar o fluxo moderno de build:

```bash
npm install
npm run dev
npm run build
```

A fonte de CSS está em `src/css/theme.css`; `src/css/app.css` adiciona as camadas do Tailwind. O JavaScript de build está em `src/js/main.js` e importa o Swiper via npm.

Nesta V0.2 o WordPress ainda carrega o Swiper por CDN para que o ZIP funcione imediatamente sem `node_modules`. Na próxima etapa, após gerar o primeiro build do Vite, podemos alterar `functions.php` para ler o `manifest.json` e servir apenas os bundles locais.

## Agenda

Cada item da agenda é um post do tipo **Evento**. A relação com Banda e Casa é feita por ACF/Post Object. Isso permite, depois, mostrar automaticamente:

- agenda da banda em `single-banda.php`;
- agenda da casa;
- agenda geral por data;
- filtros por cidade, banda, casa e período;
- eventos passados separados dos próximos.
