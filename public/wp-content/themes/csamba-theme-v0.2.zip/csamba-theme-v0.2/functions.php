<?php
if (!defined('ABSPATH')) exit;

define('CSAMBA_VERSION', '0.2.0');

function csamba_setup(): void {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('html5', ['search-form','gallery','caption','style','script']);
    add_image_size('csamba-card', 520, 320, true);
    add_image_size('csamba-hero', 980, 620, true);
    add_image_size('csamba-thumb', 240, 160, true);
    register_nav_menus([
        'primary' => 'Menu principal',
        'band'    => 'Menu da banda',
    ]);
}
add_action('after_setup_theme', 'csamba_setup');

function csamba_assets(): void {
    // Swiper local pode ser incorporado pelo Vite depois; por enquanto, CDN estável e cacheável.
    wp_enqueue_style('swiper', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', [], '11');
    wp_enqueue_style('csamba-main', get_template_directory_uri() . '/assets/css/main.css', ['swiper'], CSAMBA_VERSION);
    wp_enqueue_script('swiper', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', [], '11', true);
    wp_enqueue_script('csamba-main', get_template_directory_uri() . '/assets/js/main.js', ['swiper'], CSAMBA_VERSION, true);
}
add_action('wp_enqueue_scripts', 'csamba_assets');

function csamba_register_content_types(): void {
    $types = [
        'banda'  => ['Bandas','Banda','dashicons-groups', true],
        'casa'   => ['Casas','Casa','dashicons-admin-home', true],
        'evento' => ['Agenda','Evento','dashicons-calendar-alt', true],
        'coluna' => ['Colunas','Coluna','dashicons-welcome-write-blog', true],
    ];
    foreach ($types as $slug => [$plural,$singular,$icon,$archive]) {
        register_post_type($slug, [
            'labels' => [
                'name'=>$plural,
                'singular_name'=>$singular,
                'add_new_item'=>"Adicionar $singular",
                'edit_item'=>"Editar $singular"
            ],
            'public' => true,
            'has_archive' => $archive,
            'rewrite' => ['slug' => $slug === 'banda' ? 'bandas' : ($slug === 'evento' ? 'agenda' : $slug)],
            'menu_icon' => $icon,
            'supports' => ['title','editor','excerpt','thumbnail'],
            'show_in_rest' => true,
        ]);
    }

    register_taxonomy('genero', ['banda'], [
        'label' => 'Gêneros',
        'public' => true,
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'genero'],
    ]);
}
add_action('init', 'csamba_register_content_types');

/** ACF: campos versionados no tema. Funciona com ACF Free. */
function csamba_register_acf_fields(): void {
    if (!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key' => 'group_csamba_menu',
        'title' => 'CSamba — Menu',
        'fields' => [[
            'key' => 'field_csamba_menu_color',
            'label' => 'Cor do item',
            'name' => 'csamba_menu_color',
            'type' => 'color_picker',
            'default_value' => '#2878d7',
        ]],
        'location' => [[['param'=>'nav_menu_item','operator'=>'==','value'=>'all']]],
    ]);

    acf_add_local_field_group([
        'key' => 'group_csamba_banda',
        'title' => 'CSamba — Banda',
        'fields' => [
            ['key'=>'field_csamba_destaque','label'=>'Exibir nos destaques','name'=>'csamba_destaque','type'=>'true_false','ui'=>1],
            ['key'=>'field_csamba_slide_color','label'=>'Cor do botão do destaque','name'=>'csamba_slide_color','type'=>'color_picker','default_value'=>'#2878d7'],
            ['key'=>'field_csamba_subtitulo','label'=>'Subtítulo do destaque','name'=>'csamba_subtitulo','type'=>'text'],
        ],
        'location' => [[['param'=>'post_type','operator'=>'==','value'=>'banda']]],
    ]);

    acf_add_local_field_group([
        'key' => 'group_csamba_evento',
        'title' => 'CSamba — Evento / Agenda',
        'fields' => [
            ['key'=>'field_evento_data','label'=>'Data','name'=>'evento_data','type'=>'date_picker','display_format'=>'d/m/Y','return_format'=>'Ymd','required'=>1],
            ['key'=>'field_evento_hora','label'=>'Horário','name'=>'evento_hora','type'=>'time_picker','display_format'=>'H:i','return_format'=>'H:i'],
            ['key'=>'field_evento_banda','label'=>'Banda','name'=>'evento_banda','type'=>'post_object','post_type'=>['banda'],'return_format'=>'id','allow_null'=>1],
            ['key'=>'field_evento_casa','label'=>'Casa / Local','name'=>'evento_casa','type'=>'post_object','post_type'=>['casa'],'return_format'=>'id','allow_null'=>1],
            ['key'=>'field_evento_cidade','label'=>'Cidade','name'=>'evento_cidade','type'=>'text'],
            ['key'=>'field_evento_ingresso','label'=>'Link de ingressos','name'=>'evento_ingresso','type'=>'url'],
        ],
        'location' => [[['param'=>'post_type','operator'=>'==','value'=>'evento']]],
    ]);
}
add_action('acf/init', 'csamba_register_acf_fields');

function csamba_menu_link_color(array $atts, WP_Post $item, stdClass $args): array {
    if (($args->theme_location ?? '') !== 'primary' || !function_exists('get_field')) return $atts;
    $color = get_field('csamba_menu_color', $item);
    if ($color) {
        $atts['style'] = trim(($atts['style'] ?? '') . ';--menu-accent:' . sanitize_hex_color($color));
    }
    return $atts;
}
add_filter('nav_menu_link_attributes', 'csamba_menu_link_color', 10, 3);

function csamba_upcoming_events(int $limit = 8): WP_Query {
    $today = current_time('Ymd');
    return new WP_Query([
        'post_type' => 'evento',
        'posts_per_page' => $limit,
        'meta_key' => 'evento_data',
        'orderby' => 'meta_value_num',
        'order' => 'ASC',
        'meta_query' => [[
            'key' => 'evento_data',
            'value' => $today,
            'compare' => '>=',
            'type' => 'NUMERIC',
        ]],
    ]);
}

function csamba_excerpt(int $words = 24): string {
    return wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), $words);
}

function csamba_placeholder(string $label='CSamba'): string {
    return 'https://placehold.co/900x560/e8e8e8/222?text=' . rawurlencode($label);
}

function csamba_image_url($post_id = null, string $size='large', string $fallback='CSamba'): string {
    $post_id = $post_id ?: get_the_ID();
    $url = get_the_post_thumbnail_url($post_id, $size);
    return $url ?: csamba_placeholder($fallback);
}

function csamba_date_label($post_id = null): string {
    $post_id = $post_id ?: get_the_ID();
    return get_the_date('j \d\e F \d\e Y', $post_id);
}
